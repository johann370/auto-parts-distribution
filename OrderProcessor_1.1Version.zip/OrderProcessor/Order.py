parts_received = (0);
full_parts_list = (0,0);
full_parts_list_by_name = ('');


setOrderStatus{
        
    parts_received = input("Enter the part received: ");
    full_parts_list = full_parts_list + parts_received;
}
part_number = 0;
part_name = '';

editPartName(part_number){
    part_name = input("Enter the new part name: ");
}
part_payment_amount = 0.00;
full_payment_amount = 0.00;
payment_process_completed = 0;

inputPartPaymentAmount{
    payment_amount = "Enter the payment amount for the part: ";
    full_payment_amount += part_payment_amount;
}
